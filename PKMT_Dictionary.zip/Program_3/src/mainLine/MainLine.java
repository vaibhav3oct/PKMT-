package mainLine;

import addresses.IndiaAddress;
import addresses.QatarBusinessAddress;
import addresses.UnitedStatesAddress;
import javafx.application.Application;

import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;

import javafx.scene.layout.Pane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import mainLine.UserInterface;

/*******
 * <p>
 * Title: Exercise04Main Class.
 * </p>
 * 
 * <p>
 * Description: A JavaFX demonstration application: This controller class is the
 * entry point for this JavaFX application.
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2018-08-04
 * </p>
 * 
 * @author Lynn Robert Carter (Baseline)
 * @author Vaibhav Kumar Mishra  (Modified Baseline)
 * @since  6/09/2018
 * @version 1.0 2018-07-18 Baseline
 * @version 2.0 2018-08-04 Enhance the baseline to read definitions into an
 *          array of definitions
 * 
 */

public class MainLine extends Application {

	public UserInterface theGUI;
	
	public static double WINDOW_WIDTH;
	public static double WINDOW_HEIGHT;

	@Override
	/**********
	 
	 * 
	 * @param theStage is a Stage object that is passed in to the methods and is
	 *                 used to set up the the controlling object for the
	 *                 application's user interface
	 */
	public void start(Stage theStage) throws Exception {
		UnitedStatesAddress lrcarterAddress = new UnitedStatesAddress("Lynn Robert Carter",
				"3857 East Equestrian Trail", "Phoenix", "Arizona", "85044-3008", "USA");

		// Demonstrate that the Qatar Address holds the data and prints it properly
		QatarBusinessAddress cmuQatarAddress = new QatarBusinessAddress("Office of Undergraduate Admissions",
				"Carnegie Mellon University", "c/o Qatar Foundation", "P.O. Box 24866", "Doha", "Qatar");

		IndiaAddress MMuAddress = new IndiaAddress("Maharishi Markandeshwar (Deemed to be University),",
				"Ambala - Yamunanagar Highway,", "Mullana - Ambala, 133-207 (Haryana)", "India", "", "");

		// Determine the actual visual bounds for this display
		Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

		// set Stage boundaries to the visual bounds so the window does not totally fill
		// the screen
		WINDOW_WIDTH = primaryScreenBounds.getWidth() - primaryScreenBounds.getMinX() - 100;
		if (WINDOW_WIDTH > 900)
			WINDOW_WIDTH = 900;
		WINDOW_HEIGHT = primaryScreenBounds.getHeight() - primaryScreenBounds.getMinY() - 100;
		if (WINDOW_HEIGHT > 800)
			WINDOW_HEIGHT = 600;

		theStage.setTitle("Exercise 04"); // Label the stage's window
		Pane root = new Pane();
		Pane theRoot = new Pane(); // Create a pane within the window
		Pane theRoot1 = new Pane(); 
		Pane theRoot2 = new Pane(); 
		theGUI = new UserInterface(theRoot); // Create the Graphical User Interface
		theGUI = new UserInterface(theRoot1); 
		theGUI = new UserInterface(theRoot2); 
		theGUI.appendAddress(lrcarterAddress, cmuQatarAddress, MMuAddress); // and populate that Pane with widgets

		TabPane tabPane = new TabPane();

		BorderPane borderPane = new BorderPane();

		Tab Add = new Tab();
		Add.setText("Contacts  ");
		Add.setContent(theRoot2);
		Tab Dic = new Tab();
		Dic.setText("Dictionary");
		Dic.setContent(theRoot);
		Tab Spa = new Tab();
		Spa.setText("Spare");
		Spa.setContent(theRoot1);
		
		tabPane.getTabs().addAll(Add, Dic, Spa);
		borderPane.setCenter(tabPane);
		root.getChildren().add(borderPane);
		
		Rectangle2D primaryScreenBounds1 = Screen.getPrimary().getVisualBounds();
		WINDOW_WIDTH = primaryScreenBounds1.getWidth() - primaryScreenBounds1.getMinX() - 100;
		if (WINDOW_WIDTH > 1000) WINDOW_WIDTH = 1000;
		WINDOW_HEIGHT = primaryScreenBounds1.getHeight() - primaryScreenBounds1.getMinY() - 100;
		if (WINDOW_HEIGHT > 800) WINDOW_HEIGHT = 600;
		
		Rectangle2D primaryScreenBounds2 = Screen.getPrimary().getVisualBounds();
		WINDOW_WIDTH = primaryScreenBounds2.getWidth() - primaryScreenBounds1.getMinX() - 100;
		if (WINDOW_WIDTH > 1000) WINDOW_WIDTH = 1000;
		WINDOW_HEIGHT = primaryScreenBounds2.getHeight() - primaryScreenBounds1.getMinY() - 100;
		if (WINDOW_HEIGHT > 800) WINDOW_HEIGHT = 600;

		theStage.setTitle("Personal Knowledge Management Tool"); // Label the stage's window

		// Create a pane within the window

		// Create the Graphical User Interface
		// and populate that Pane with widgets

		Scene theScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT); // Create the scene using
		// the GUI window and the size that
		// was computed earlier

		theStage.setScene(theScene); // Set the scene on the stage and

		theStage.show(); // show the stage to the user

		// When the stage is shown to the user, the pane within the window is now
		// visible. This means
		// that any Graphical User Interface (GUI) that were established are now visible
		// and it is now
		// possible for the user to select input fields and enter values into them,
		// click on buttons,
		// and read the labels, the results, and the error messages.
	}
	// Create the scene using
	// the GUI window and the size that
	// was computed earlier

	

	/*******************************************************************************************************/

	/*******************************************************************************************************
	 * This is the method that launches the JavaFX application
	 * 
	 * @param args are the program parameters and they are not used by this program.
	 * 
	 */
	public static void main(String[] args) { // This method may not be required
		launch(args); // for all JavaFX applications using
	} // other IDEs.

}
